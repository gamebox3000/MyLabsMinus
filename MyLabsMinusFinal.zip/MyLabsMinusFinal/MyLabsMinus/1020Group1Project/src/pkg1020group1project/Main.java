/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1020group1project;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * the main class
 * @author mboyson
 */
public class Main {

    /**
     * main method
     * @param args args
     * @throws FileNotFoundException for files not found
     * @throws IOException for input output errors
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        UserData.update();
        UserInterface.open();
    }
    
}
