/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1020group1project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * The UserData class manages the temporary data and its flow to and from permanent storage.
 * @author Jonathan Babb
 * @author Stephen Hyberger
 */
public class UserData {
    public static ArrayList<Parent> parents = new ArrayList<>();
    public static ArrayList<Student> students = new ArrayList<>();
    public static ArrayList<Teacher> teachers = new ArrayList<>();
    static File studentFile = new File("Student.txt");
    static File parentFile = new File("Parent.txt");
    static File teacherFile = new File("Teacher.txt");
    /**
     * Adds user to the corresponding arrayList.
     * @param user The User to add to the arrayLists
     * @throws IOException when a generic User is the parameter.
     */
    public static void addUser(User user) throws IOException{
        if (user instanceof Student) {
            students.add((Student) user);
        } else if (user instanceof Parent) {
            parents.add((Parent) user);
        } else if (user instanceof Teacher) {
            teachers.add((Teacher) user);
        } else {
            throw new IllegalArgumentException("Tried to add generic User");
        }
        save();
    }
    /**
     * Converts data in the .txt files to objects in the array lists 
     * should be ran before class is used
     * @throws FileNotFoundException in case files cant be found
     * @throws IOException in case files cant be read
     */
    public static void update() throws FileNotFoundException, IOException{
        if(!studentFile.exists()) studentFile.createNewFile();
        if(!parentFile.exists()) parentFile.createNewFile();
        if(!teacherFile.exists()) teacherFile.createNewFile();
        Scanner sIn = new Scanner(studentFile);
        Scanner pIn = new Scanner(parentFile);
        Scanner tIn = new Scanner(teacherFile);
        sIn.useDelimiter("\\Z");
        pIn.useDelimiter("\\Z");
        tIn.useDelimiter("\\Z");
        String[] sStrings = sIn.next().split(";\n");
        for(String s : sStrings){
            String temp[] = s.split(",");
            String userName = temp[0];
            String lastName = temp[1];
            String firstName = temp[2];
            String email = temp[3];
            String teacherUN = temp[4];
            students.add(new Student(userName, firstName, lastName, email, teacherUN));
        }
        String[] pStrings = pIn.next().split(";\n");
        for(String p : pStrings){
            String temp[] = p.split(",");
            String userName = temp[0];
            String lastName = temp[1];
            String firstName = temp[2];
            String email = temp[3];
            String studentNum = temp[4];
            parents.add(new Parent(userName, firstName, lastName, email, studentNum));
        }
        String[] tStrings = tIn.next().split(";\n");
        for(String t: tStrings){
            String temp[] = t.split(",");
            String userName = temp[0];
            String lastName = temp[1];
            String firstName = temp[2];
            String email = temp[3];
            String studentNum = temp[4];
            teachers.add(new Teacher(userName, firstName, lastName, email, studentNum));
        }
    }
    /**
     * Writes the data in the array lists to the .txt files
     * @throws IOException in case files cannot be writen to
     */
    public static void save() throws IOException{
        if(!studentFile.exists()) studentFile.createNewFile();
        if(!parentFile.exists()) parentFile.createNewFile();
        if(!teacherFile.exists()) teacherFile.createNewFile();
        PrintWriter sOut = new PrintWriter(studentFile);
        PrintWriter pOut = new PrintWriter(parentFile);
        PrintWriter tOut = new PrintWriter(teacherFile);
        for(Teacher t: teachers){
            tOut.print(t.getUserName()+","+t.getFirstName()+","+t.getLastName()+","+t.getEMail()+","+t.getNumberOfStudents()+";\n");
        }
        tOut.close();
        for(Parent p: parents){
            pOut.print(p.getUserName()+","+p.getFirstName()+","+p.getLastName()+","+p.getEMail()+","+p.getNumberOfChildren()+";\n");
        }
        pOut.close();
        for(Student s: students){
            sOut.print(s.getUserName()+","+s.getFirstName()+","+s.getLastName()+","+s.getEMail()+","+s.getTeacherUserName()+";\n");
        }
        sOut.close();
    }
    /**
     * returns list of users
     * @param includeParents include parents in list
     * @param includeStudents include students in list
     * @param includeTeachers include teachers in list
     * @return list of users
     */
    public static String listUser(boolean includeParents, boolean includeStudents, boolean includeTeachers){
        String userList = "";
        int count = 1;
        if(includeParents){
            for(Parent parent: parents){
                userList += "\n"+count+". "+parent.getUserName();
                count++;
            }
        }
        if (includeStudents){
            for(Student student: students){
                userList += "\n"+count+". "+student.getUserName();
                count++;
            }
        }
        if (includeTeachers){
            for(Teacher teacher: teachers){
                userList += "\n"+count+". "+teacher.getUserName();
                count++;
            }
        }
        return userList;
    }
    /**
     * The contains method checks for a match between the username parameter and all the usernames in the arrayLists.
     * @param userName The user name to check for.
     * @return True if match is found and false if there is no match.
     */
    public static boolean contains(String userName) {
        boolean doesContain = false;
        for (Parent parent : parents) {
            if (parent.getUserName().equals(userName)) {
                doesContain = true;
            }
        }
        for (Student student : students) {
            if (student.getUserName().equals(userName)) {
                doesContain = true;
            }
        }
        for (Teacher teacher : teachers) {
            if (teacher.getUserName().equals(userName)) {
                doesContain = true;
            }
        }
        return doesContain;
    }
    /**
     * gets the type of user inputed
     * @param userName username to search for
     * @return the type of user as represented by a string
     */
    public static String getUserType(String userName){
        String type = "";
        for (Parent parent : parents) {
            if (parent.getUserName().equals(userName)) {
                type = "parent";
            }
        }
        for (Student student : students) {
            if (student.getUserName().equals(userName)) {
                type = "student";
            }
        }
        for (Teacher teacher : teachers) {
            if (teacher.getUserName().equals(userName)) {
                type = "teacher";
            }
        }
        return type;
    }
    /**
     * Returns the User with the specified username.
     * @param userName The username of the User to return
     * @return The User with the matching user name to the parameter.
     * @throws IllegalArgumentException if the User is not found.
     */
    public static User getUser(String userName) {
        if (contains(userName)) {
            for (Parent parent : parents) {
                if (parent.getUserName().equals(userName)) {
                    return parent;
                }
            }
            for (Student student : students) {
                if (student.getUserName().equals(userName)) {
                    return student;
                }
            }
            for (Teacher teacher : teachers) {
                if (teacher.getUserName().equals(userName)) {
                    return teacher;
                }
            }
        } else {
            throw new IllegalArgumentException("User not found");
        }
        return null;
    }
    /**
     * Prints all the details of the User with the user name matching the parameter.
     * @param userName The username of the User.
     * @throws IllegalArgumentException if the user is not found.
     * @return formated user data
     */
    public static String getDetails(String userName) {
        if (contains(userName)) {
            for (Parent parent : parents) {
                if (parent.getUserName().equals(userName)) {
                    return parent.toString();
                }
            }
            for (Student student : students) {
                if (student.getUserName().equals(userName)) {
                    return student.toString();
                }
            }
            for (Teacher teacher : teachers) {
                if (teacher.getUserName().equals(userName)) {
                    return teacher.toString();
                }
            }
        } 
        return null;
    }
}